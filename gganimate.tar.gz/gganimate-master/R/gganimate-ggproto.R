#' Base ggproto classes for gganimate
#'
#' If you are creating a new transition, view, etc. in another package,
#' you'll need to extend from some of the ggproto classes defined in `gganimate`
#'
#' @seealso ggproto
#' @keywords internal
#' @name gganimate-ggproto
NULL
